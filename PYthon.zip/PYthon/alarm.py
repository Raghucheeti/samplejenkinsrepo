import json
import boto3
 
client = boto3.client('sns')
ec2client = boto3.client('ec2')
def lambda_handler(event, context):
    message = json.loads(event['Records'][0]['Sns']['Message'])
    print(json.dumps(message))
    message = json.dumps(message)
    print(json.loads(message)['detail'])
 
    response = ec2client.describe_instances()
    for reservation in response["Reservations"]:
        for instance in reservation["Instances"]:
            if str(instance["InstanceId"]) == str(json.loads(message)['detail']['instance-id']):
                print(instance)
                print(instance["Tags"])
                name = 'NA'
                sid = 'NA'
                if 'Tags' in instance:
                    for i in range(len(instance['Tags'])):
                        if 'Key' in instance['Tags'][i]:
                            if 'Name' in instance['Tags'][i]['Key']:
                                name = instance['Tags'][i]['Value']
                            if 'Sid' in instance['Tags'][i]['Key']:
                                sid = instance['Tags'][i]['Value']
                message_to_send = "You are receiving this alarm as the EC2 instance with ID {:} has changed of state - {:} at {:}. Following are additional details - Name - {:} and SID - {:}".format(
                    json.loads(message)['detail']['instance-id'], json.loads(message)['detail']['state'],
                    json.loads(message)['time'], name, sid)
                print(message_to_send)
   
                response = client.publish(
                    TargetArn='arn:aws:sns:us-east-1:237980099910:SAMPLE2',
                    Message=json.dumps({'default': json.dumps(message_to_send)}),
                    MessageStructure='json'
                )
   
                print(response)